<?php
fwrite(STDOUT, "Hello master.\n");
fwrite(STDOUT, "Master write: ".fgets(STDIN)."\n");

